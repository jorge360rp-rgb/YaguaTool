var YaguStudioMotion={enter:function(){}};
