Propuesta visual 3.1.3: abre mock/index.html. Las acciones de AE se simulan en esta propuesta. Usa el instalable nativo de after-effects/3.1.3 para abrir el panel en AE.
