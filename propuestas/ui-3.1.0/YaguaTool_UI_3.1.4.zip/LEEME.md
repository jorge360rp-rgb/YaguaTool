Propuesta visual 3.1.4: abre mock/index.html. Botones Glass y cierres ampliados. Para ejecutar en AE utiliza el paquete completo after-effects/3.1.4 y su instalador.
