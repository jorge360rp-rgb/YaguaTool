Propuesta visual 3.1.2. Abre mock/index.html. Las acciones de After Effects se simulan en esta propuesta. Para ejecutar en AE utiliza el paquete nativo after-effects/3.1.2.
